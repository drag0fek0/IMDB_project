﻿// env-config.js
const env = 'local'; // or server when deployed
const BASE_URL = env === 'local' ? '.' : 'https://proj.ruppin.ac.il/cgroup11/test2/tar2/imdbclient5';
const API_URL = env === 'local' ? 'https://localhost:7041/api' : 'https://proj.ruppin.ac.il/cgroup11/test2/tar1/api';
const LOGIN_URL = `${BASE_URL}/logIn.html`;
const REGISTER_URL = `${BASE_URL}/register.html`;
const INDEX_URL = `${BASE_URL}/index.html`;
const MY_MOVIES_URL = `${BASE_URL}/MyMovies.html`;
const SUBMIT_MOVIE_URL = `${BASE_URL}/submitMovie.html`;
const MOVIES_API_URL = `${API_URL}/Movies`;
const Users_API_URL = `${API_URL}/Users`;
const USERSETTINGS_URL = `${BASE_URL}/UserSettingsPage.html`;
