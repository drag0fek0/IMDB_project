﻿const languages = [
    "American Sign Language", "Amharic", "Arabic", "Belarusian", "Cantonese", "Czech", "Danish", "English", "Esperanto",
    "French", "Gaelic", "German", "Greek", "Hebrew", "Hindi", "Hmong", "Hungarian", "Irish Gaelic", "Italian", "Japanese",
    "Japanese Sign Language", "Kalmyk-Oirat", "Kikuyu", "Kinyarwanda", "Korean", "Kurdish", "Latin", "Latvian", "Mandarin",
    "Nepali", "Norwegian", "Old English", "Persian", "Polish", "Portuguese", "Quechua", "Quenya", "Russian", "Saami",
    "Sicilian", "Sindarin", "Spanish", "Swahili", "Swedish", "Tagalog", "Tamil", "Thai", "Turkish", "Vietnamese", "Xhosa",
    "Yiddish", "Zulu"
];

const genres = [
    "Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Drama", "Family", "Fantasy", "Film-Noir",
    "History", "Horror", "Music", "Musical", "Mystery", "Romance", "Sci-Fi", "Sport", "Thriller", "War", "Western"
];