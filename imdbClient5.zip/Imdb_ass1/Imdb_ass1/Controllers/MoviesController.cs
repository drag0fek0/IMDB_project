﻿using Imdb_ass1.BL;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Imdb_ass1.Controllers {
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase {
        // GET: api/<MoviesController>
        [HttpGet]
        public ActionResult<IEnumerable<Movie>> Get() {
            try {
                return Ok(Movie.read());
            } catch (Exception ex) {
                return StatusCode(500, new { message = $"Internal server error: {ex.Message}" });
            }

        }

        [HttpGet("search")]
        public ActionResult<IEnumerable<Movie>> SearchByTitle(string title) {

            Movie movie = new Movie();
            var result = movie.GetByTitle(title);

            return Ok(result);
        }

        [HttpGet("searchByRouting/from/{startDate}/until/{endDate}")]
        public ActionResult<IEnumerable<Movie>> SearchByReleaseDate(DateTime startDate, DateTime endDate) {
            Movie movie = new Movie();
            var result = movie.GetByReleaseDate(startDate, endDate);

            return Ok(result);
        }


        // POST api/<MoviesController>
        [HttpPost]
        public ActionResult Post([FromBody] Movie movie) {
            try {
                bool inserted = movie.insert();
                if (!inserted) {
                    return Conflict(new { message = "Movie Already Exists." });
                }
                return CreatedAtAction(nameof(Get), new { id = movie.Id }, new { movie });
            } catch (Exception ex) {
                return StatusCode(500, new { message = $"Internal server error: {ex.Message}" });
            }

        }
        [HttpDelete("{id}")]
        public ActionResult Delete(int id) {
            Movie movie = new Movie();
            bool ans = movie.deleteMovie(id);

            if (ans) {
                return Ok();
            }
            return Ok(new { message = "No such movie." });
        }

        [HttpPost("rent")]
        public bool Post([FromBody] RentedMovie movie) {
            RentedMovie m = new RentedMovie();
            return m.RentMovie(movie);
        }

        [HttpPost("StrongInsert")]
        public int Post([FromBody] List<Movie> movies) {
            Movie m = new Movie();
            return m.strongInsert(movies);
        }

    }
}
