﻿using System.Text.RegularExpressions;
using BCrypt.Net;
using Imdb_ass1.BL;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Imdb_ass1.Controllers {
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase {
        // GET: api/<UsersController>
        [HttpGet]
        public ActionResult<IEnumerable<User>> Get() {
            try {
                //{

                //    var users = user.read(); 

                //    if (users.Count == 0)
                //    {
                //        return NotFound("No users in the database.");
                //    }

                //    return Ok(users);
                User user = new User();
                var users = user.read();
                return Ok(users);
            } catch (Exception ex) {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpPost("cart/{userId:int}/{movieId:int}")]
        public IActionResult AddToCart(int userId, int movieId) {
            try {
                User user = new User();
                int added = user.AddToCart(userId, movieId);
                if (added == 0)
                    return Conflict("That movie is already in your cart.");

                var movie = Movie.read().FirstOrDefault(m => m.Id == movieId);
                return Ok(new { movie });
            } catch (Exception ex) {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("cart/{userId:int}")]
        public IActionResult GetCart(int userId) {
            try {
                User user = new User();
                var movies = user.GetUserCart(userId);
                return Ok(movies);
            } catch (Exception ex) {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] User userUpdate) {
            try {
                if (userUpdate.Id != id)
                    return BadRequest("User ID mismatch.");

                int result = userUpdate.Update();

                if (result > 0) {
                    // returning new info
                    var match = new User().read().FirstOrDefault(u => u.Id == id);

                    return Ok(match);
                }

                if (result < 0)
                    return Conflict("Email already exists.");

                // result == 0
                return BadRequest("No changes detected or user not found.");
            } catch (Exception ex) {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("cart/{userId:int}/{movieId:int}")]
        public ActionResult Delete(int userId, int movieId) {
            try {
                User user = new User();
                int ans = user.DeleteCartItem(userId, movieId);
                if (ans == 0)
                    return NotFound($"No cart entry found for user {userId} & movie {movieId}.");
                return Ok($"Movie {movieId} removed from user {userId} cart.");
            } catch (Exception ex) {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }

        }

        // POST api/<UsersController>
        [HttpPost]
        public ActionResult Post([FromBody] User user) {
            try {
                string passwordHash = BCrypt.Net.BCrypt.HashPassword(user.Password, 13);

                user.Password = passwordHash;

                bool inserted;
                inserted = user.insert();
                if (!inserted) {
                    return Conflict("User Already Exists or Missing Info.");
                }
                // returning the id of the new user
                var match = new User().read().FirstOrDefault(u => u.Email.Equals(user.Email, StringComparison.OrdinalIgnoreCase));

                return Ok(new { match.Id, user.Name, user.Email, match.Active });

            } catch (Exception ex) {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("Login")]
        public ActionResult Login([FromBody] loginDT login) {
            try {
                var match = new User().read().FirstOrDefault(u => u.Email.Equals(login.Email, StringComparison.OrdinalIgnoreCase));

                if (match == null || !BCrypt.Net.BCrypt.Verify(login.Password, match.Password)) {
                    return Unauthorized("Invalid credentials.");
                }

                return Ok(new { match.Id, match.Name, match.Email, match.Active });
            } catch (Exception ex) {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpDelete("{id}")]
        public ActionResult Delete(int id) {
            try {
                var user = new User();
                bool deleted = user.delete(id);

                if (!deleted) {
                    return NotFound($"User with ID {id} not found or already deleted.");
                }
                return Ok($"User {id} deleted.");
            } catch (Exception ex) {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


    }
}
