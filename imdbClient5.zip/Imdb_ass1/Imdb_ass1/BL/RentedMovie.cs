﻿namespace Imdb_ass1.BL {
    public class RentedMovie {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int MovieId { get; set; }
        public DateTime RentStart { get; set; }
        public DateTime RentEnd { get; set; }
        public double TotalPrice { get; set; }
        public DateTime? DeletedAt { get; set; }

        // Full‐args ctor
        public RentedMovie(int userId, int movieId, DateTime rentStart, DateTime rentEnd, double totalPrice, DateTime? deletedAt) {
            UserId = userId;
            MovieId = movieId;
            RentStart = rentStart;
            RentEnd = rentEnd;
            TotalPrice = totalPrice;
            DeletedAt = deletedAt;
        }

        // For the data‐reader / model binder
        public RentedMovie() { }

        public bool RentMovie(RentedMovie movie) {
            DBservices dbs = new DBservices();
            return dbs.RentMovie(movie) == 1;
        }
    }
}

