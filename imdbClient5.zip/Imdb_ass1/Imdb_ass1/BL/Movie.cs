﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Imdb_ass1.BL {
    public class Movie {
        private int id;
        private int priceToRent, rentalCount, year, runtimeMinutes, numVotes;
        private DateTime releaseDate;
        private string url, primaryTitle, description, primaryImage, language, genres;
        private double budget, grossWorldwide;
        private bool isAdult;
        private float averageRating;
        private static List<Movie> MovieList = new List<Movie>();

        public Movie(int year, int runtimeMinutes, int numVotes, DateTime releaseDate, string url, string primaryTitle, string description, string primaryImage, string language, string genres, double budget, double grossWorldwide, bool isAdult, float averageRating, int priceToRent, int rentalCount) {
            // Check for duplicate titles.
            if (MovieList.Any(m => m.PrimaryTitle.Equals(primaryTitle, StringComparison.OrdinalIgnoreCase))) {
                throw new Exception("Movie with the same title already exists.");
            }

            Year = year;
            RuntimeMinutes = runtimeMinutes;
            NumVotes = numVotes;
            ReleaseDate = releaseDate;
            Url = url;
            PrimaryTitle = primaryTitle;
            Description = description;
            PrimaryImage = primaryImage;
            Language = language;
            Genres = genres;
            Budget = budget;
            GrossWorldwide = grossWorldwide;
            IsAdult = isAdult;
            AverageRating = averageRating;
            this.priceToRent = priceToRent;
            this.rentalCount = rentalCount;
        }

        // Parameterless constructor.
        public Movie() { }

        public int Year { get => year; set => year = value; }
        public int RuntimeMinutes { get => runtimeMinutes; set => runtimeMinutes = value; }
        public int NumVotes { get => numVotes; set => numVotes = value; }
        public DateTime ReleaseDate { get => releaseDate; set => releaseDate = value; }
        public string Url { get => url; set => url = value; }
        public string PrimaryTitle { get => primaryTitle; set => primaryTitle = value; }
        public string Description { get => description; set => description = value; }
        public string PrimaryImage { get => primaryImage; set => primaryImage = value; }
        public string Language { get => language; set => language = value; }
        public string Genres { get => genres; set => genres = value; }
        public double Budget { get => budget; set => budget = value; }
        public double GrossWorldwide { get => grossWorldwide; set => grossWorldwide = value; }
        public bool IsAdult { get => isAdult; set => isAdult = value; }
        public float AverageRating { get => averageRating; set => averageRating = value; }
        public int Id { get; set; }

        public int PriceToRent { get => priceToRent; set => priceToRent = value; }
        public int RentalCount { get => rentalCount; set => rentalCount = value; }

        public bool insert() {
            //// Check for valid data.
            //if (string.IsNullOrEmpty(this.primaryTitle) || this.releaseDate == default(DateTime))
            //    return false;

            //// Check for duplicate movies (based on title).
            //if (MovieList.Any(m => m.PrimaryTitle.Equals(this.primaryTitle, StringComparison.OrdinalIgnoreCase)))
            //{
            //    return false;
            //}

            //// If the ID is 0 (default), assign it from idCounter.
            //if (this.id == 0)
            //{
            //    this.id = idCounter;
            //    idCounter++;  // Increment the counter only once here.
            //}

            //MovieList.Add(this);
            return true;
        }



        // Return the list of movies.
        public static List<Movie> read() {
            DBservices dbs = new DBservices();
            return dbs.GetAllMovies();
        }

        public List<Movie> GetByTitle(string title) {
            DBservices dbs = new DBservices();
            return dbs.SearchMoviesByTitle(title);
        }

        public List<Movie> GetByReleaseDate(DateTime startDate, DateTime endDate) {
            DBservices dbs = new DBservices();
            return dbs.SearchMoviesByDates(startDate, endDate);
        }

        public bool deleteMovie(int id) {
            foreach (Movie movie in MovieList) {
                if (movie.id == id) {
                    MovieList.Remove(movie);
                    return true;
                }
            }
            return false;
        }


        public int strongInsert(List<Movie> movies) {
            DBservices dbs = new DBservices();
            return dbs.strongInsert(movies);
        }


        public override bool Equals(object? obj) {
            return obj is Movie movie &&
                   primaryTitle.Equals(movie.PrimaryTitle) &&
                   id.Equals(movie.id);
        }

        public bool Update(Movie movie) {
            DBservices dbs = new DBservices();
            return dbs.UpdateMovie(movie) == 1;
        }
    }
}
