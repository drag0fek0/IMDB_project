﻿namespace Imdb_ass1.BL {
    public class User {
        //private static int idCounter =1;
        //private int id;
        private string name, email, password;
        private bool active = true;
        private DateTime? deletedAt;
        //private static List<User> UsersList = new List<User>();

        public User(string name, string email, string password, bool active) {

            Name = name;
            Email = email;
            Password = password;
            Active = active;
            //id = idCounter++;
        }
        public User() { }

        public int Id { get; set; }
        public string? Name { get => name; set => name = value; }
        public string? Email { get => email; set => email = value; }
        public string? Password { get => password; set => password = value; }
        public bool? Active { get; set; }
        public DateTime? DeletedAt { get => deletedAt; set => deletedAt = value; }

        public int AddToCart(int userId, int movieId) {
            DBservices dbs = new DBservices();
            return dbs.AddToCart(userId, movieId);
        }
        public bool insert() {
            //if (string.IsNullOrEmpty(this.name) || string.IsNullOrEmpty(this.email) || string.IsNullOrEmpty(this.password))
            //    return false;

            //foreach (User user in UsersList)
            //{
            //    if (user.Equals(this))
            //    {
            //        return false;
            //    }
            //}

            //// Assign id if it's not already set
            //if (id == 0)
            //{
            //    id = idCounter++;
            //}

            //UsersList.Add(this);
            //return true;
            try {
                if (string.IsNullOrEmpty(this.name) || string.IsNullOrEmpty(this.email) || string.IsNullOrEmpty(this.password))
                    return false;
                DBservices dbs = new DBservices();
                List<User> existingUsers = dbs.readUsers();

                if (existingUsers.Any(u => u.Email.Equals(this.email, StringComparison.OrdinalIgnoreCase))) {
                    return false;
                }
                return dbs.insertUser(this) > 0;

            } catch (Exception ex) {
                return false;
            }
        }

        public List<Movie> GetUserCart(int id) {
            DBservices dbs = new DBservices();
            return dbs.GetCartMoviesByUser(id);
        }
        public List<User> read() {
            DBservices dbs = new DBservices();
            return dbs.readUsers();
        }
        public int Update() {
            // 1) Load existing
            DBservices dbs = new DBservices();
            User existing = dbs.readUsers().FirstOrDefault(u => u.Id == this.Id);
            if (existing == null)
                return 0;  // treat "not found" as no change

            // 2) Apply changes in-memory
            bool changed = false;
            if (!string.IsNullOrEmpty(this.Name) && existing.Name != this.Name) {
                existing.Name = this.Name;
                changed = true;
            }
            if (!string.IsNullOrEmpty(this.Email) && existing.Email != this.Email) {
                existing.Email = this.Email;
                changed = true;
            }
            if (!string.IsNullOrEmpty(this.Password) && !BCrypt.Net.BCrypt.Verify(this.Password, existing.Password)) {
                existing.Password = BCrypt.Net.BCrypt.HashPassword(this.Password, 13);
                changed = true;
            }
            if (this.Active != null && existing.Active != this.Active) {
                existing.Active = this.Active;
                changed = true;
            }

            if (!changed)
                return 0;  // no fields changed

            // 3) Persist
            return dbs.updateUser(existing); // can be 1 (ok) or -1 (conflict)
        }
        public bool delete(int id) {
            DBservices dbs = new DBservices();
            int rows = dbs.deleteUser(id);
            return rows > 0;
        }
        public List<Movie> GetUserCartMovies(int id) {
            DBservices dbs = new DBservices();
            return dbs.GetCartMoviesByUser(id);
        }
        public int DeleteCartItem(int userId, int movieId) {
            DBservices dbs = new DBservices();
            return dbs.DeleteCartItem(userId, movieId);
        }
        public override bool Equals(object? obj) {
            return obj is User user && (user.email.ToLower().Equals(email.ToLower()));
        }

    }
}
