﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using Imdb_ass1.BL;

/// <summary>
/// DBServices is a class created by me to provides some DataBase Services
/// </summary>
public class DBservices {


    public DBservices() {
        //
        // TODO: Add constructor logic here
        //
    }

    //--------------------------------------------------------------------------------------------------
    // This method creates a connection to the database according to the connectionString name in the appsettings.json 
    //--------------------------------------------------------------------------------------------------
    public SqlConnection connect(String conString) {

        // read the connection string from the configuration file
        IConfigurationRoot configuration = new ConfigurationBuilder()
        .AddJsonFile("appsettings.json").Build();
        string cStr = configuration.GetConnectionString("myProjDB");
        SqlConnection con = new SqlConnection(cStr);
        con.Open();
        return con;
    }
    public List<User> readUsers() {
        SqlConnection con;
        SqlCommand cmd;
        List<User> users = new List<User>();

        try {
            con = connect("myProjDB");
        } catch (Exception ex) {
            throw ex;
        }
        cmd = CreateCommandWithStoredProcedureGeneral("sp_GetAllUsers", con, null);
        try {
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read()) {
                User user = new User {
                    Id = Convert.ToInt32(dr["Id"]),
                    Name = dr["Username"].ToString(),
                    Email = dr["Email"].ToString(),
                    Password = dr["Password"].ToString(),
                    Active = Convert.ToBoolean(dr["active"]),
                    DeletedAt = dr["DeletedAt"] == DBNull.Value ? null : (DateTime?)Convert.ToDateTime(dr["DeletedAt"])
                };
                users.Add(user);
            }
            dr.Close();
            return users;

        } catch (Exception ex) {
            throw new Exception("Error reading users", ex);
        } finally {
            if (con != null)
                con.Close();
        }

    }

    public int strongInsert(List<Movie> movies) {
        SqlConnection con;
        SqlCommand cmd;
        int totalInserted = 0;
        try {
            con = connect("myProjDB");
        } catch (Exception ex) {
            throw ex;
        }

        foreach (var movie in movies) {
            // Set dynamic/default values
            int PriceToRent = new Random().Next(10, 31);

            Dictionary<string, object> paramDic = new Dictionary<string, object>
        {
            {"@PrimaryTitle", movie.PrimaryTitle },
            {"@Description", movie.Description },
            {"@Year", movie.Year },
            {"@RuntimeMinutes", movie.RuntimeMinutes },
            {"@Genres", movie.Genres },
            {"@Language", movie.Language },
            {"@Budget", movie.Budget },
            {"@GrossWorldWide", movie.GrossWorldwide },
            {"@IsAdult", movie.IsAdult },
            {"@AverageRating", movie.AverageRating },
            {"@NumVotes", movie.NumVotes },
            {"@ReleaseDate", movie.ReleaseDate },
            {"@Url", movie.Url },
            {"@PrimaryImage", movie.PrimaryImage },
            {"@PriceToRent", PriceToRent },
        };

            cmd = CreateCommandWithStoredProcedureGeneral("SP_InitialInsert_IMDB", con, paramDic);

            try {
                totalInserted += cmd.ExecuteNonQuery();
            } catch (Exception ex) {
                Console.WriteLine($"Error inserting movie: {movie.PrimaryTitle}\n{ex.Message}");
            }
        }

        con.Close();
        return totalInserted;
    }

    public int insertUser(User user) {
        SqlConnection con = null;
        SqlCommand cmd = null;

        try {
            con = connect("myProjDb");

            var paramDic = new Dictionary<string, object> {
                { "@Username", user.Name },
                { "@Email", user.Email },
                { "@Password", user.Password },
                { "@Active", user.Active }
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_InsertUser", con, paramDic);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected;
        } catch (Exception ex) {
            throw new Exception("Error inserting user", ex);
        } finally {
            if (con != null) {
                // close the db connection
                con.Close();
            }
        }
    }
    public int updateUser(User user) {
        SqlConnection con = null;
        SqlCommand cmd = null;

        try {
            con = connect("myProjDb");

            var paramDic = new Dictionary<string, object> {
                { "@Id", user.Id },
                { "@Username", user.Name },
                { "@Email", user.Email },
                { "@Password", user.Password },
                { "@Active", user.Active }
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_UpdateUser", con, paramDic);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected;
        } catch (SqlException sqlEx) {
            if (sqlEx.Number == 2627 || sqlEx.Number == 2601) // UNIQUE constraint violation
            {
                return -1; // email error
            }
            throw; // other db errors - throw
        } catch (Exception ex) {
            throw new Exception("Error updating user", ex);
        } finally {
            if (con != null) {
                // close the db connection
                con.Close();
            }
        }
    }

    public int UpdateMovie(Movie movie) {
        SqlConnection con = null;
        SqlCommand cmd = null;

        try {
            con = connect("myProjDb");

            Dictionary<string, object> paramDic = new Dictionary<string, object> {
                    {"@Url", movie.Url},
                    {"@PrimaryTitle", movie.PrimaryTitle},
                    {"@Description", movie.Description},
                    {"@PrimaryImage", movie.PrimaryImage},
                    {"@Year", movie.Year},
                    {"@ReleaseDate", movie.ReleaseDate},
                    {"@Language", movie.Language},
                    {"@Budget", movie.Budget},
                    {"@GrossWorldWide", movie.GrossWorldwide},
                    {"@Genres", movie.Genres},
                    {"@IsAdult", movie.IsAdult},
                    {"@RuntimeMinutes", movie.RuntimeMinutes},
                    {"@AverageRating", movie.AverageRating},
                    {"@NumVotes", movie.NumVotes},
                    {"@PriceToRent", movie.PriceToRent},
                    {"@RentalCount", movie.RentalCount},
                };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_UpdateMovie", con, paramDic);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected;
        } catch (SqlException sqlEx) {
            if (sqlEx.Number == 2627 || sqlEx.Number == 2601) {
                return -1; // email error
            }
            throw; // other db errors - throw
        } catch (Exception ex) {
            throw new Exception("Error updating user", ex);
        } finally {
            if (con != null) {
                // close the db connection
                con.Close();
            }
        }
    }

    public int RentMovie(RentedMovie rent) {
        SqlConnection con = null;
        SqlCommand cmd = null;

        try {
            con = connect("myProjDb");

            var paramDic = new Dictionary<string, object> {
                { "@UserId", rent.Id },
                { "@MovieId", rent.MovieId },
                { "@RentStart", rent.RentStart},
                { "@RentEnd", rent.RentEnd },
                { "@TotalPrice", rent.TotalPrice }
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_FinalizeRental", con, paramDic);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected;
        } catch (Exception ex) {
            throw new Exception("Error updating user", ex);
        } finally {
            if (con != null) {
                // close the db connection
                con.Close();
            }
        }
    }
    public List<RentedMovie> GetRentedMoviesForUser(int userId) {
        var list = new List<RentedMovie>();
        SqlConnection con = null;
        SqlCommand cmd = null;

        try {
            con = connect("myProjDb");

            var paramDic = new Dictionary<string, object> {
                { "@UserId", userId }
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_GetUserRents", con, paramDic);
            using var dr = cmd.ExecuteReader();
            while (dr.Read()) {
                list.Add(new RentedMovie {
                    Id = (int)dr["Id"],
                    UserId = (int)dr["UserId"],
                    MovieId = (int)dr["MovieId"],
                    RentStart = (DateTime)dr["RentStart"],
                    RentEnd = (DateTime)dr["RentEnd"],
                    TotalPrice = Convert.ToDouble(dr["TotalPrice"]),
                    DeletedAt = dr["DeletedAt"] == DBNull.Value
                                 ? null
                                 : (DateTime?)dr["DeletedAt"]
                });
            }
            return list;
        } catch (Exception ex) {
            throw new Exception("Error updating user", ex);
        } finally {
            if (con != null) {
                // close the db connection
                con.Close();
            }
        }
    }
    public int AddToCart(int UserId, int MovieId) {
        SqlConnection con = null;
        SqlCommand cmd = null;

        try {
            con = connect("myProjDb");

            var paramDic = new Dictionary<string, object> {
                { "@UserId", UserId },
                {"@MovieId",MovieId }
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_AddToCart1", con, paramDic);
            cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int)
           .Direction = ParameterDirection.ReturnValue;

            cmd.ExecuteNonQuery();
            var ret = (int)cmd.Parameters["@RETURN_VALUE"].Value!;
            return ret;
        } catch (Exception ex) {
            throw new Exception("Error updating user", ex);
        } finally {
            if (con != null) {
                // close the db connection
                con.Close();
            }
        }
    }
    public List<Movie> GetCartMoviesByUser(int userId) {
        var list = new List<Movie>();
        SqlConnection con = null;
        SqlCommand cmd = null;

        try {
            con = connect("myProjDb");

            var paramDic = new Dictionary<string, object> {
                { "@UserId", userId }
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_GetCartMoviesByUser", con, paramDic);
            using var dr = cmd.ExecuteReader();
            while (dr.Read()) {
                list.Add(new Movie {
                    Id = Convert.ToInt32(dr["Id"]),
                    PrimaryTitle = dr["PrimaryTitle"].ToString(),
                    Description = dr["Description"].ToString(),
                    Year = Convert.ToInt32(dr["Year"]),
                    RuntimeMinutes = Convert.ToInt32(dr["RuntimeMinutes"]),
                    Genres = dr["Genres"].ToString(),
                    Language = dr["Language"].ToString(),
                    Budget = Convert.ToDouble(dr["Budget"]),
                    GrossWorldwide = Convert.ToDouble(dr["GrossWorldwide"]),
                    IsAdult = Convert.ToBoolean(dr["IsAdult"]),
                    AverageRating = Convert.ToSingle(dr["AverageRating"]),
                    NumVotes = Convert.ToInt32(dr["NumVotes"]),
                    ReleaseDate = dr["ReleaseDate"] as DateTime? ?? default,
                    Url = dr["Url"].ToString(),
                    PrimaryImage = dr["PrimaryImage"].ToString(),
                    PriceToRent = Convert.ToInt32(dr["PriceToRent"]),
                    RentalCount = Convert.ToInt32(dr["RentalCount"])
                });
            }
            return list;
        } catch (Exception ex) {
            throw new Exception("Error updating user", ex);
        } finally {
            if (con != null) {
                // close the db connection
                con.Close();
            }
        }
    }
    public List<Movie> SearchMoviesByDates(DateTime start, DateTime end) {
        var movies = new List<Movie>();
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        try {
            con = connect("myProjDb");
            var paramDic = new Dictionary<string, object> {
                { "@StartDate ", start },
                { "@EndDate",end}
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_SearchMoviesByDateRange", con, paramDic);
            dr = cmd.ExecuteReader();
            while (dr.Read()) {
                var movie = new Movie {
                    Id = Convert.ToInt32(dr["Id"]),
                    PrimaryTitle = dr["PrimaryTitle"].ToString(),
                    Description = dr["Description"].ToString(),
                    Year = Convert.ToInt32(dr["Year"]),
                    RuntimeMinutes = Convert.ToInt32(dr["RuntimeMinutes"]),
                    Genres = dr["Genres"].ToString(),
                    Language = dr["Language"].ToString(),
                    Budget = Convert.ToDouble(dr["Budget"]),
                    GrossWorldwide = Convert.ToDouble(dr["GrossWorldwide"]),
                    IsAdult = Convert.ToBoolean(dr["IsAdult"]),
                    AverageRating = Convert.ToSingle(dr["AverageRating"]),
                    NumVotes = Convert.ToInt32(dr["NumVotes"]),
                    ReleaseDate = dr["ReleaseDate"] as DateTime? ?? default,
                    Url = dr["Url"].ToString(),
                    PrimaryImage = dr["PrimaryImage"].ToString(),
                    PriceToRent = Convert.ToInt32(dr["PriceToRent"]),
                    RentalCount = Convert.ToInt32(dr["RentalCount"])
                };
                movies.Add(movie);
            }
            return movies;
        } catch (Exception ex) {
            throw new Exception("Error reading movies", ex);
        } finally {
            dr?.Close();
            if (con != null) con.Close();
        }
    }
    public int DeleteCartItem(int userId, int movieId) {
        SqlConnection con = null;
        SqlCommand cmd = null;

        try {
            con = connect("myProjDb");
            var paramDic = new Dictionary<string, object> {
                { "@UserId ", userId },
                {"@MovieId",movieId }
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_DeleteCartItem", con, paramDic);
            return cmd.ExecuteNonQuery();

        } catch (Exception ex) {
            throw new Exception("Error reading movies", ex);
        } finally {
            if (con != null) con.Close();
        }
    }
    public List<Movie> SearchMoviesByTitle(string title) {
        var movies = new List<Movie>();
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        try {
            con = connect("myProjDb");
            var paramDic = new Dictionary<string, object> {
                { "@SearchTerm ", title }
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_SearchMoviesByTitle", con, paramDic);
            dr = cmd.ExecuteReader();
            while (dr.Read()) {
                var movie = new Movie {
                    Id = Convert.ToInt32(dr["Id"]),
                    PrimaryTitle = dr["PrimaryTitle"].ToString(),
                    Description = dr["Description"].ToString(),
                    Year = Convert.ToInt32(dr["Year"]),
                    RuntimeMinutes = Convert.ToInt32(dr["RuntimeMinutes"]),
                    Genres = dr["Genres"].ToString(),
                    Language = dr["Language"].ToString(),
                    Budget = Convert.ToDouble(dr["Budget"]),
                    GrossWorldwide = Convert.ToDouble(dr["GrossWorldwide"]),
                    IsAdult = Convert.ToBoolean(dr["IsAdult"]),
                    AverageRating = Convert.ToSingle(dr["AverageRating"]),
                    NumVotes = Convert.ToInt32(dr["NumVotes"]),
                    ReleaseDate = dr["ReleaseDate"] as DateTime? ?? default,
                    Url = dr["Url"].ToString(),
                    PrimaryImage = dr["PrimaryImage"].ToString(),
                    PriceToRent = Convert.ToInt32(dr["PriceToRent"]),
                    RentalCount = Convert.ToInt32(dr["RentalCount"])
                };
                movies.Add(movie);
            }
            return movies;
        } catch (Exception ex) {
            throw new Exception("Error reading movies", ex);
        } finally {
            dr?.Close();
            if (con != null) con.Close();
        }
    }
    public List<Movie> GetAllMovies() {
        var movies = new List<Movie>();
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        try {
            con = connect("myProjDb");
            cmd = CreateCommandWithStoredProcedureGeneral("sp_GetAllMovies", con, null);
            dr = cmd.ExecuteReader();
            while (dr.Read()) {
                var movie = new Movie {
                    Id = Convert.ToInt32(dr["Id"]),
                    PrimaryTitle = dr["PrimaryTitle"].ToString(),
                    Description = dr["Description"].ToString(),
                    Year = Convert.ToInt32(dr["Year"]),
                    RuntimeMinutes = Convert.ToInt32(dr["RuntimeMinutes"]),
                    Genres = dr["Genres"].ToString(),
                    Language = dr["Language"].ToString(),
                    Budget = Convert.ToDouble(dr["Budget"]),
                    GrossWorldwide = Convert.ToDouble(dr["GrossWorldwide"]),
                    IsAdult = Convert.ToBoolean(dr["IsAdult"]),
                    AverageRating = Convert.ToSingle(dr["AverageRating"]),
                    NumVotes = Convert.ToInt32(dr["NumVotes"]),
                    ReleaseDate = dr["ReleaseDate"] as DateTime? ?? default,
                    Url = dr["Url"].ToString(),
                    PrimaryImage = dr["PrimaryImage"].ToString(),
                    PriceToRent = Convert.ToInt32(dr["PriceToRent"]),
                    RentalCount = Convert.ToInt32(dr["RentalCount"])
                };
                movies.Add(movie);
            }
            return movies;
        } catch (Exception ex) {
            throw new Exception("Error reading movies", ex);
        } finally {
            dr?.Close();
            if (con != null) con.Close();
        }
    }
    public int deleteUser(int id) {
        SqlConnection con = null;
        SqlCommand cmd = null;

        try {
            con = connect("myProjDb");

            var paramDic = new Dictionary<string, object> {
                { "@Id", id }
            };
            cmd = CreateCommandWithStoredProcedureGeneral("sp_DeleteUserIMDB", con, paramDic);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected;
        } catch (Exception ex) {
            throw new Exception("Error inserting user", ex);
        } finally {
            if (con != null) {
                // close the db connection
                con.Close();
            }
        }
    }
    //---------------------------------------------------------------------------------
    // Create the SqlCommand
    //---------------------------------------------------------------------------------
    private SqlCommand CreateCommandWithStoredProcedureGeneral(String spName, SqlConnection con, Dictionary<string, object> paramDic) {

        SqlCommand cmd = new SqlCommand(); // create the command object

        cmd.Connection = con;              // assign the connection to the command object

        cmd.CommandText = spName;      // can be Select, Insert, Update, Delete 

        cmd.CommandTimeout = 10;           // Time to wait for the execution' The default is 30 seconds

        cmd.CommandType = System.Data.CommandType.StoredProcedure; // the type of the command, can also be text

        if (paramDic != null)
            foreach (KeyValuePair<string, object> param in paramDic) {
                cmd.Parameters.AddWithValue(param.Key, param.Value);

            }


        return cmd;
    }




}
